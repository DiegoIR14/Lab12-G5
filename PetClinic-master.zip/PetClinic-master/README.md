# Application PetClinic

## This application uses Spring Boot 

## v1.0.0 --> Version with unit test

## v2.0.0 --> Version with integration test

## v3.0.0 --> Version with continuous integration 

### - mvn test -P dev  --> aplication-dev.properties 
### - mvn test -P test --> aplication-test.properties
### - mvn test -P prod --> aplication-prod.properties